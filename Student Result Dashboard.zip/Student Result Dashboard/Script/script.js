function addStudent() {
    const name = document.getElementById("name").value;
    const gujarati = Number(document.getElementById("gujarati").value);
    const hindi = Number(document.getElementById("hindi").value);
    const english = Number(document.getElementById("english").value);

    if (!name || gujarati < 0 || hindi < 0 || english < 0) {
        alert("Please enter valid details");
        return;
    }

    const total = gujarati + hindi + english;
    const percentage = (total / 300 * 100).toFixed(2);

    const listItem = document.createElement("li");
    listItem.textContent = `${name} - ${percentage}%`;

    document.getElementById("studentList").appendChild(listItem);

    // Clear input fields
    document.getElementById("name").value = "";
    document.getElementById("gujarati").value = "";
    document.getElementById("hindi").value = "";
    document.getElementById("english").value = "";
}
