import React from 'react';
import { FaReact, FaNodeJs, FaHtml5, FaCss3Alt, FaJs, FaDatabase } from 'react-icons/fa';
import { SiTypescript, SiMongodb, SiExpress } from 'react-icons/si';
import './Skills.css';

const frontendSkills = [
    { name: 'React.js', icon: FaReact, color: '#61dafb' },
    { name: 'TypeScript', icon: SiTypescript, color: '#3178c6' },
    { name: 'HTML5', icon: FaHtml5, color: '#e34c26' },
    { name: 'CSS3', icon: FaCss3Alt, color: '#1572b6' },
    { name: 'JavaScript', icon: FaJs, color: '#f7df1e' },
];

const backendSkills = [
    { name: 'Node.js', icon: FaNodeJs, color: '#3c873a' },
    { name: 'Express.js', icon: SiExpress, color: '#000' },
    { name: 'MongoDB', icon: SiMongodb, color: '#47a248' },
    { name: 'SQL', icon: FaDatabase, color: '#00758f' },
];

const Skills: React.FC = () => {
    return (
        <section id="skills" className="skills-unique">
            <h2 className="skills-title">Skills</h2>
            <div className="skills-cards-container">
                <div className="skills-card glass">
                    <h3 className="skills-card-title">Frontend</h3>
                    <ul className="skills-list">
                        {frontendSkills.map((skill) => {
                            const Icon = skill.icon;
                            return (
                                <li key={skill.name} className="skill-item">
                                    <span className="skill-icon">{Icon({ color: skill.color })}</span>
                                    <span>{skill.name}</span>
                                </li>
                            );
                        })}
                    </ul>
                </div>
                <div className="skills-card glass">
                    <h3 className="skills-card-title">Backend</h3>
                    <ul className="skills-list">
                        {backendSkills.map((skill) => {
                            const Icon = skill.icon;
                            return (
                                <li key={skill.name} className="skill-item">
                                    <span className="skill-icon">{Icon({ color: skill.color })}</span>
                                    <span>{skill.name}</span>
                                </li>
                            );
                        })}
                    </ul>
                </div>
            </div>
        </section>
    );
};

export default Skills; 