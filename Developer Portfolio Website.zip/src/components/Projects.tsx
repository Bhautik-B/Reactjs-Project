import React from 'react';

interface Project {
    title: string;
    description: string;
    technologies: string[];
    image: string;
    githubLink: string;
    liveLink: string;
    resources?: string[];
}

const projects: Project[] = [
    {
        title: "E-Commerce Platform",
        description: "A full-stack e-commerce platform with user authentication, product management, and payment integration.",
        technologies: ["React", "Node.js", "MongoDB", "Stripe"],
        image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8ZWNvbW1lcmNlfGVufDB8fDB8fHww",
        githubLink: "https://github.com/Bhautik-B",
        liveLink: "https://your-ecommerce-site.com",
        resources: [
            "User Authentication",
            "Product Catalog",
            "Shopping Cart",
            "Payment Processing",
            "Order Management"
        ]
    },
    {
        title: "Task Management App",
        description: "A collaborative task management application with real-time updates and team features.",
        technologies: ["React", "Firebase", "Material-UI"],
        image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8dGFzayUyMG1hbmFnZW1lbnR8ZW58MHx8MHx8fDA%3D",
        githubLink: "https://github.com/Bhautik-B",
        liveLink: "https://your-task-manager.com",
        resources: [
            "Real-time Updates",
            "Team Collaboration",
            "Task Prioritization",
            "Progress Tracking",
            "Deadline Management"
        ]
    },
    {
        title: "Weather Dashboard",
        description: "A weather dashboard that displays current and forecasted weather data using external APIs.",
        technologies: ["React", "OpenWeather API", "Chart.js"],
        image: "https://images.unsplash.com/photo-1592210454359-9043f067919b?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8d2VhdGhlcnxlbnwwfHwwfHx8MA%3D%3D",
        githubLink: "https://github.com/Bhautik-B",
        liveLink: "https://your-weather-app.com",
        resources: [
            "Current Weather",
            "5-Day Forecast",
            "Location Search",
            "Weather Maps",
            "Historical Data"
        ]
    }
];

const ProjectCard: React.FC<{ project: Project }> = ({ project }) => {
    return (
        <div className="project-card">
            <img src={project.image} alt={project.title} className="project-image" />
            <div className="project-content">
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <div className="project-technologies">
                    {project.technologies.map((tech, index) => (
                        <span key={index} className="tech-tag">{tech}</span>
                    ))}
                </div>
                {project.resources && (
                    <div className="project-resources">
                        <h4>Key Features:</h4>
                        <ul>
                            {project.resources.map((resource, index) => (
                                <li key={index}>{resource}</li>
                            ))}
                        </ul>
                    </div>
                )}
                <div className="project-links">
                    <a href={project.githubLink} target="_blank" rel="noopener noreferrer" className="project-link">
                        GitHub
                    </a>
                    <a href={project.liveLink} target="_blank" rel="noopener noreferrer" className="project-link">
                        Live Demo
                    </a>
                </div>
            </div>
        </div>
    );
};

const Projects: React.FC = () => {
    return (
        <section id="projects" className="projects">
            <h2>My Projects</h2>
            <div className="projects-grid">
                {projects.map((project, index) => (
                    <ProjectCard key={index} project={project} />
                ))}
            </div>
        </section>
    );
};

export default Projects; 