import React from 'react';
import './About.css';
import { FaGithub, FaLinkedin, FaDownload } from 'react-icons/fa';
// Use a placeholder avatar image
const avatar = "https://ui-avatars.com/api/?name=Bhautik&background=0984e3&color=fff";

const About: React.FC = () => {
    return (
        <section id="about" className="about-modern">
            <h2 className="about-title">About Me</h2>
            <div className="about-card glass">
                <div className="about-avatar-container">
                    <img src={avatar} alt="Profile" className="about-avatar animated-avatar" />
                    <div className="about-social-links">
                        <a href="https://github.com/Bhautik-B" target="_blank" rel="noopener noreferrer" title="GitHub">
                            {FaGithub({ color: "#0984e3", size: "1.5em" })}
                        </a>
                        <a href="https://www.linkedin.com/in/bhautik-ghevariya-326836369" target="_blank" rel="noopener noreferrer" title="LinkedIn">
                            {FaLinkedin({ color: "#0984e3", size: "1.5em" })}
                        </a>
                        <a href="/resume.pdf" download title="Download Resume">
                            {FaDownload({ color: "#0984e3", size: "1.5em" })}
                        </a>
                    </div>
                </div>
                <div className="about-text-modern">
                    <p>
                        I am a passionate and motivated <span className="highlight-keyword">Frontend Developer</span> with a Bachelor's degree in <span className="highlight-keyword">Computer Applications (BCA)</span>. As a fresher, I bring strong foundational knowledge in web development programming. I have hands-on experience with <span className="highlight-keyword">ReactJS</span>, along with a good command of <span className="highlight-keyword">HTML</span>, <span className="highlight-keyword">CSS</span>, and <span className="highlight-keyword">JavaScript</span>. I am eager to apply my skills to real-world projects, learn from industry professionals, and grow into a strong <span className="highlight-keyword">full-stack developer</span> over time. I am committed to building efficient, scalable, and secure backend systems. I feel that my skills are best suited for your firm because during my tenure at <span className="highlight-keyword">BCA Collage</span>, I designed and implemented systems and solutions in different frameworks and I am confident that my analytical, collaborative, and adaptable nature, along with my in-depth knowledge of multiple technology stacks, will make me a valuable asset to your team. I am eager to bring my expertise to a new and exciting challenge and contribute to the continued success of your organization. Thank you for considering my application. I am confident that my background aligns well with the requirements of the position, and I am enthusiastic about the opportunity to bring my skills and experiences to your team.
                    </p>
                </div>
            </div>
        </section>
    );
};

export default About; 